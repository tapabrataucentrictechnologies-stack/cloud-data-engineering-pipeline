import csv
import json
import os
from pathlib import Path

from dotenv import load_dotenv
from google.cloud import bigquery


load_dotenv()


PROJECT_ID = os.getenv("GCP_PROJECT_ID")
DATASET_ID = os.getenv("BIGQUERY_DATASET")

BASE_DIR = Path(__file__).resolve().parents[2]
PROCESSED_DIRECTORY = BASE_DIR / "data" / "processed"


def get_bigquery_client():
    """Create and return a BigQuery client."""

    if not PROJECT_ID:
        raise ValueError("GCP_PROJECT_ID is not configured.")

    if not DATASET_ID:
        raise ValueError("BIGQUERY_DATASET is not configured.")

    return bigquery.Client(project=PROJECT_ID)


def create_dataset():
    """Create the BigQuery dataset if it does not already exist."""

    client = get_bigquery_client()

    dataset_id = f"{PROJECT_ID}.{DATASET_ID}"

    dataset = bigquery.Dataset(dataset_id)
    dataset.location = "US"

    dataset = client.create_dataset(
        dataset,
        exists_ok=True
    )

    return dataset.dataset_id


def test_bigquery_connection():
    """Test the BigQuery connection."""

    client = get_bigquery_client()

    query = """
        SELECT 1 AS test_value
    """

    result = client.query(query).result()

    row = next(iter(result))

    return row["test_value"]


def load_customers():
    """Load processed customers CSV into BigQuery."""

    client = get_bigquery_client()

    table_id = f"{PROJECT_ID}.{DATASET_ID}.customers"

    file_path = PROCESSED_DIRECTORY / "customers.csv"

    if not file_path.exists():
        raise FileNotFoundError(
            f"Customers file not found: {file_path}"
        )

    schema = [
        bigquery.SchemaField("customer_id", "INTEGER"),
        bigquery.SchemaField("name", "STRING"),
        bigquery.SchemaField("email", "STRING"),
        bigquery.SchemaField("city", "STRING"),
        bigquery.SchemaField("country", "STRING"),
        bigquery.SchemaField("signup_date", "DATE"),
    ]

    job_config = bigquery.LoadJobConfig(
        schema=schema,
        source_format=bigquery.SourceFormat.CSV,
        skip_leading_rows=1,
        field_delimiter=",",
        write_disposition=bigquery.WriteDisposition.WRITE_TRUNCATE,
        max_bad_records=0,
        ignore_unknown_values=False,
    )

    print("\nLoading customers...")

    with file_path.open("rb") as file_handle:
        load_job = client.load_table_from_file(
            file_handle,
            table_id,
            job_config=job_config,
        )

    load_job.result()

    if load_job.errors:
        raise RuntimeError(
            f"Customers load failed: {load_job.errors}"
        )

    table = client.get_table(table_id)

    print(f"  Customers loaded: {table.num_rows} rows")

    return table


def read_orders_csv():
    """
    Read the processed orders CSV and convert values
    to the correct Python data types.
    """

    file_path = PROCESSED_DIRECTORY / "orders.csv"

    if not file_path.exists():
        raise FileNotFoundError(
            f"Orders file not found: {file_path}"
        )

    expected_columns = [
        "order_id",
        "customer_id",
        "product_id",
        "order_date",
        "quantity",
        "price",
    ]

    orders = []

    with file_path.open(
        "r",
        newline="",
        encoding="utf-8"
    ) as file_handle:

        reader = csv.DictReader(file_handle)

        if reader.fieldnames != expected_columns:
            raise ValueError(
                "Invalid orders.csv columns.\n"
                f"Expected: {expected_columns}\n"
                f"Found: {reader.fieldnames}"
            )

        for row in reader:

            orders.append(
                {
                    "order_id": int(row["order_id"]),
                    "customer_id": int(row["customer_id"]),
                    "product_id": int(row["product_id"]),
                    "order_date": row["order_date"],
                    "quantity": int(row["quantity"]),
                    "price": float(row["price"]),
                }
            )

    if len(orders) == 0:
        raise ValueError(
            "orders.csv contains no data rows."
        )

    return orders


def load_orders():
    """
    Load processed orders into BigQuery.

    The processed CSV is validated first and converted
    to newline-delimited JSON before loading into the
    partitioned BigQuery table.
    """

    client = get_bigquery_client()

    table_id = f"{PROJECT_ID}.{DATASET_ID}.orders"

    print("\nLoading orders...")

    # -------------------------------------------------
    # 1. Read and validate the processed CSV
    # -------------------------------------------------

    orders = read_orders_csv()

    print(f"  Validated local orders: {len(orders)} rows")

    # -------------------------------------------------
    # 2. Convert records to NDJSON
    # -------------------------------------------------

    ndjson_path = PROCESSED_DIRECTORY / "orders_bigquery.ndjson"

    with ndjson_path.open(
        "w",
        encoding="utf-8"
    ) as file_handle:

        for order in orders:
            file_handle.write(
                json.dumps(order) + "\n"
            )

    print(f"  Created BigQuery staging file: {ndjson_path}")

    # -------------------------------------------------
    # 3. Define BigQuery schema
    # -------------------------------------------------

    schema = [
        bigquery.SchemaField("order_id", "INTEGER"),
        bigquery.SchemaField("customer_id", "INTEGER"),
        bigquery.SchemaField("product_id", "INTEGER"),
        bigquery.SchemaField("order_date", "DATE"),
        bigquery.SchemaField("quantity", "INTEGER"),
        bigquery.SchemaField("price", "FLOAT"),
    ]

    # -------------------------------------------------
    # 4. Configure BigQuery load
    # -------------------------------------------------

    job_config = bigquery.LoadJobConfig(
        schema=schema,
        source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
        write_disposition=bigquery.WriteDisposition.WRITE_TRUNCATE,
        max_bad_records=0,
        ignore_unknown_values=False,
    )

    # Partition orders by order_date.
    job_config.time_partitioning = bigquery.TimePartitioning(
        type_=bigquery.TimePartitioningType.DAY,
        field="order_date",
    )

    # Cluster by customer and product.
    job_config.clustering_fields = [
        "customer_id",
        "product_id",
    ]

    # -------------------------------------------------
    # 5. Load into BigQuery
    # -------------------------------------------------

    with ndjson_path.open(
        "rb"
    ) as file_handle:

        load_job = client.load_table_from_file(
            file_handle,
            table_id,
            job_config=job_config,
        )

    print(f"  Load job ID: {load_job.job_id}")

    load_job.result()

    # -------------------------------------------------
    # 6. Check load errors
    # -------------------------------------------------

    if load_job.errors:
        raise RuntimeError(
            f"Orders load failed: {load_job.errors}"
        )

    # -------------------------------------------------
    # 7. Verify table
    # -------------------------------------------------

    table = client.get_table(table_id)

    print(f"  Orders loaded: {table.num_rows} rows")

    if table.num_rows != len(orders):
        raise RuntimeError(
            f"BigQuery orders table contains "
            f"{table.num_rows} rows, but "
            f"{len(orders)} rows were expected."
        )

    print("  Orders verification: PASSED")

    return table


def load_products():
    """Load processed products CSV into BigQuery."""

    client = get_bigquery_client()

    table_id = f"{PROJECT_ID}.{DATASET_ID}.products"

    file_path = PROCESSED_DIRECTORY / "products.csv"

    if not file_path.exists():
        raise FileNotFoundError(
            f"Products file not found: {file_path}"
        )

    schema = [
        bigquery.SchemaField("product_id", "INTEGER"),
        bigquery.SchemaField("product_name", "STRING"),
        bigquery.SchemaField("category", "STRING"),
    ]

    job_config = bigquery.LoadJobConfig(
        schema=schema,
        source_format=bigquery.SourceFormat.CSV,
        skip_leading_rows=1,
        field_delimiter=",",
        write_disposition=bigquery.WriteDisposition.WRITE_TRUNCATE,
        max_bad_records=0,
        ignore_unknown_values=False,
    )

    print("\nLoading products...")

    with file_path.open("rb") as file_handle:
        load_job = client.load_table_from_file(
            file_handle,
            table_id,
            job_config=job_config,
        )

    load_job.result()

    if load_job.errors:
        raise RuntimeError(
            f"Products load failed: {load_job.errors}"
        )

    table = client.get_table(table_id)

    print(f"  Products loaded: {table.num_rows} rows")

    return table


def load_all_tables():
    """Load all processed datasets into BigQuery."""

    print("=" * 60)
    print("BIGQUERY DATA WAREHOUSE LOAD")
    print("=" * 60)

    create_dataset()

    customers_table = load_customers()

    orders_table = load_orders()

    products_table = load_products()

    print("\n" + "=" * 60)
    print("BIGQUERY LOAD COMPLETED SUCCESSFULLY")
    print("=" * 60)

    print("\nFinal row counts:")
    print(f"  customers: {customers_table.num_rows}")
    print(f"  orders:    {orders_table.num_rows}")
    print(f"  products:  {products_table.num_rows}")

    return {
        "customers": customers_table,
        "orders": orders_table,
        "products": products_table,
    }


if __name__ == "__main__":
    load_all_tables()