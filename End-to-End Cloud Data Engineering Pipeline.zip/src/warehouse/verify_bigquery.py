from src.warehouse.bigquery_loader import get_bigquery_client, PROJECT_ID, DATASET_ID


def main():
    client = get_bigquery_client()

    tables = ["customers", "orders", "products"]

    print("=" * 60)
    print("BIGQUERY WAREHOUSE VERIFICATION")
    print("=" * 60)

    for table_name in tables:
        table_id = f"{PROJECT_ID}.{DATASET_ID}.{table_name}"

        table = client.get_table(table_id)

        print(f"\nTable: {table_name}")
        print(f"Rows: {table.num_rows}")
        print("Columns:")

        for field in table.schema:
            print(f"  - {field.name}: {field.field_type}")

        if table_name == "orders":
            print(f"Partitioned by: {table.time_partitioning.field}")
            print(f"Clustered by: {table.clustering_fields}")

    print("\n" + "=" * 60)
    print("VERIFICATION COMPLETED")
    print("=" * 60)


if __name__ == "__main__":
    main()